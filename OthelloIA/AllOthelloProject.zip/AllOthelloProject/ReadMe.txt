

You can execute the game with the instruction make and then with ./reversi.exe

PD: Sometimes you will have to wait the IA to make a move, because it will be thinking.
